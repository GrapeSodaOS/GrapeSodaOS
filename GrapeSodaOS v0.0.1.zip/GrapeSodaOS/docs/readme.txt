                                     GrapeSodaOS
                                       Readme
---------------------------------------------------------------------------------------
GrapeSodaOS is an operating system designed to bring clarity to your world. GrapeSodaOS
does that by doing stuff like transparency effects, etc. We are currently working on the
bootloader, which is going to have full configuration options, and it will support flat
binary kernels. The kernel we are making is going to be fully 32-bit, and fully written
in assembly. Now, you are probably thinking why assembly? Well, some people say that asm
is noy portable, and that you can't port your os to arch's like arm, and mips. Well, what
if I don't want my os to be portable. I don't want to port it to arm, because it sucks. 
I also don't want to port it to stuff like phones, because I just want this os to be a
simple desktop-only os for the x86-only arch. Also, I am only writing it in 32-bit asm, 
because I only have 4gb of ram, and I don't need more than 4gb of ram, and I want the os
to be backwards-compatible to the old windows 95/98 pc's, which only have 32-bit mode. 